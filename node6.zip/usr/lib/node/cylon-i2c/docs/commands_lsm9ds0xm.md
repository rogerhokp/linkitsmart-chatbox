# Commands

## getAccel

Gets the value of Accelerometer.

## getMag

Gets the value of Magnetometer.