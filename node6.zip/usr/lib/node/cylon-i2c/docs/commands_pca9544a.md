# Commands

## enable(callback)

Enables mux. Selects channel 0.

## disable(callback)

Disables mux.

## stop(callback)

Disables mux.

## setChannel0(callback)

Selects channel 0.

## setChannel1(callback)

Selects channel 1.

## setChannel2(callback)

Selects channel 2.

## setChannel3(callback)

Selects channel 3.

## setChannel(channel, callback)

Selects a channel 0-3. Invalid channels disable mux. 

## setChannel(channel, callback)

Selects a channel 0-3. Invalid channels disable mux. 

