# Commands

## heading()

Returns the heading data for the compass.

##### Returns 

`float`