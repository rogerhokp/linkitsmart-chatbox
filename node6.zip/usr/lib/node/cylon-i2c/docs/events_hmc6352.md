# Events

## heading

Gets triggered every time the specified interval is met.

##### Data

- **interval** - Current compass reading

## start

Sent when the device has been started and is ready to use.