# Commands

## getTemperature

Gets the value of the temperature in degrees Celsius.  Returns it as an object:

##### Return

`object`

{
    temp: 19.9
}