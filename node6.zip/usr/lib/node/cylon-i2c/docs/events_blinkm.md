# Events

## start

Sent when the device has been started and is ready to use.