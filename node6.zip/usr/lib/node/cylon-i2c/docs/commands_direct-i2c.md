# Commands

## read(register, len)

Reads i2c device for the register and number of bytes requested:

##### Return

`nil`

## write(register, data)

Writes to i2c device:

##### Return

`nil`
