## Release History

Version 0.24.0 - Use Cylon 1.3.0, add sysexCommand/sysexResponse and one-wire interfaces

Version 0.23.0 - Use Cylon 1.2.0

Version 0.22.0 - Use Cylon 1.1.0

Version 0.21.0 - Correct issue with errors in board initialization

Version 0.20.0 - Compatibility with Cylon 1.0.0

Version 0.19.0 - Compatibility with Cylon 0.22.0

Version 0.18.0 - Compatibility with Cylon 0.21.0

Version 0.17.2 - Validate if cmd is an array in I2C requests.

Version 0.17.1 - Fixes issue with I2C read not passing the command as an array

Version 0.17.0 - Compatibility with Cylon 0.20.0

Version 0.16.0 - Compatibility with Cylon 0.19.0

Version 0.15.0 - Compatibility with Cylon 0.18.0

Version 0.14.0 - Compatibility with Cylon 0.16.0

Version 0.13.1 - Add peerDependencies to package.json

Version 0.13.0 - Compatibility with Cylon 0.15.0

Version 0.12.0 - Compatibility with Cylon 0.14.0, remove node-namespace.

Version 0.11.1 - Added examples and updated adaptor

Version 0.11.0 - Update to cylon 0.12.0

Version 0.10.2 - Correct version numbers

Version 0.10.1 - CLI bugfixes

Version 0.10.0 - Updates to Cylon 0.11.0, migrated to pure JS

Version 0.9.0 - Updates to Cylon 0.10.0, CLI commands to install Firmata

Version 0.8.0 - Updates to Cylon 0.9.0, correct use of peerDependencies

Version 0.7.0 - Updates to Cylon 0.8.0

Version 0.6.0 - Updates to Cylon 0.7.0

Version 0.5.0 - Updates to Cylon 0.6.0

Version 0.4.0 - Updates to latest cylon core

Version 0.3.0 - Add support for i2c, load cylon-i2c driver set

Version 0.2.0 - Add support for PWM and servo commands, and refactor to use Basestar

Version 0.1.0 - Initial release with support for digital read/write and analog read/write
